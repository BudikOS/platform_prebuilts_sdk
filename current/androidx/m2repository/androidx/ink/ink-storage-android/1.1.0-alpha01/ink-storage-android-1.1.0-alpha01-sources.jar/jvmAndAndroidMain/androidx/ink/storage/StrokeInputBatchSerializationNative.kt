/*
 * Copyright (C) 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.ink.storage

import androidx.ink.nativeloader.NativeLoader
import androidx.ink.nativeloader.UsedByNative
import java.nio.ByteBuffer

@UsedByNative
internal object StrokeInputBatchSerializationNative {
    init {
        NativeLoader.load()
    }

    /**
     * Constructs a StrokeInputBatch from a serialized gzip-compressed
     * `ink.proto.CodedStrokeInputBatch`, which can be passed in as either a direct [ByteBuffer] or
     * as an array of bytes. This returns the address of a new-allocated native `StrokeInputBatch`,
     * which can be passed to and managed by [androidx.ink.strokes.ImmutableStrokeInputBatch].
     */
    @UsedByNative
    external fun newFromProto(
        directByteBuffer: ByteBuffer?,
        byteArray: ByteArray?,
        offset: Int,
        length: Int,
    ): Long

    @UsedByNative external fun serialize(nativeStrokeInputBatchPointer: Long): ByteArray
}
