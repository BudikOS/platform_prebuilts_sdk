/*
 * Copyright 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.javascriptengine;

import org.jspecify.annotations.NonNull;

/**
 * Indicates that streaming JavaScript code into the JS evaluation environment has failed.
 * <p>
 * The JavaScript isolate may continue to be used after this exception has been produced. The
 * JavaScript evaluation will not proceed if the JavaScript code streaming fails.
 */
public final class DataInputException extends JavaScriptException {
    public DataInputException(@NonNull String error) {
        super(error);
    }
    public DataInputException() {
        super();
    }
}
