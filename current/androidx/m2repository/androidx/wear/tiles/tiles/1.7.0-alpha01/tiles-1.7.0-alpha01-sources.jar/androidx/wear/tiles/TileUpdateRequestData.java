/*
 * Copyright 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.wear.tiles;

import androidx.annotation.RestrictTo;

import org.jspecify.annotations.NonNull;

/**
 * Holder for parameters, used when a Tile update request is triggered. This is currently a
 * placeholder to allow for future expansion, and should be filled in with an empty byte array.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public final class TileUpdateRequestData extends ProtoParcelable {
    public static final int VERSION_1 = 1;

    public static final Creator<TileUpdateRequestData> CREATOR =
            newCreator(TileUpdateRequestData.class, TileUpdateRequestData::new);

    public TileUpdateRequestData(byte @NonNull [] params, int version) {
        super(params, version);
    }

    public TileUpdateRequestData() {
        this(new byte[] {}, VERSION_1);
    }
}
