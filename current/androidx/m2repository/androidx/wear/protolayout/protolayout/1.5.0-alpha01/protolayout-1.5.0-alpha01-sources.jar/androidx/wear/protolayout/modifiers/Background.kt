/*
 * Copyright 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

@file:Suppress("FacadeClassJvmName") // Cannot be updated, the Kt name has been released

package androidx.wear.protolayout.modifiers

import android.annotation.SuppressLint
import androidx.annotation.Dimension
import androidx.annotation.Dimension.Companion.DP
import androidx.wear.protolayout.ColorBuilders.Brush
import androidx.wear.protolayout.ModifiersBuilders.Background
import androidx.wear.protolayout.ModifiersBuilders.Corner
import androidx.wear.protolayout.ModifiersBuilders.CornerRadius
import androidx.wear.protolayout.expression.RequiresSchemaVersion
import androidx.wear.protolayout.types.LayoutColor
import androidx.wear.protolayout.types.cornerRadius
import androidx.wear.protolayout.types.dp

/** Sets the background color to [color]. */
public fun LayoutModifier.background(color: LayoutColor): LayoutModifier =
    this then BaseBackgroundElement(color)

/** Sets the background brush to [brush]. */
@RequiresSchemaVersion(major = 1, minor = 500)
public fun LayoutModifier.background(brush: Brush): LayoutModifier =
    this then BaseBackgroundElement(brush = brush)

/** Clips the element to a rounded rectangle with four corners with [cornerRadius] radius. */
public fun LayoutModifier.clip(@Dimension(DP) cornerRadius: Float): LayoutModifier =
    this then BaseCornerElement(cornerRadius)

/**
 * Clips the element to a rounded shape with [x] as the radius on the horizontal axis and [y] as the
 * radius on the vertical axis for the four corners.
 */
@RequiresSchemaVersion(major = 1, minor = 400)
public fun LayoutModifier.clip(@Dimension(DP) x: Float, @Dimension(DP) y: Float): LayoutModifier {
    val r = cornerRadius(x, y)
    return this then
        BaseCornerElement(
            topLeftRadius = r,
            topRightRadius = r,
            bottomLeftRadius = r,
            bottomRightRadius = r,
        )
}

/** Clips the element to a rounded rectangle with corners specified in [corner]. */
public fun LayoutModifier.clip(corner: Corner): LayoutModifier =
    this then
        BaseCornerElement(
            cornerRadiusDp = corner.radius?.value,
            topLeftRadius = corner.topLeftRadius,
            topRightRadius = corner.topRightRadius,
            bottomLeftRadius = corner.bottomLeftRadius,
            bottomRightRadius = corner.bottomRightRadius,
        )

/**
 * Clips the top left corner of the element with [x] as the radius on the horizontal axis and [y] as
 * the radius on the vertical axis.
 */
@RequiresSchemaVersion(major = 1, minor = 400)
public fun LayoutModifier.clipTopLeft(
    @Dimension(DP) x: Float,
    @Dimension(DP) y: Float = x,
): LayoutModifier = this then BaseCornerElement(topLeftRadius = cornerRadius(x, y))

/**
 * Clips the top right corner of the element with [x] as the radius on the horizontal axis and [y]
 * as the radius on the vertical axis.
 */
@RequiresSchemaVersion(major = 1, minor = 400)
public fun LayoutModifier.clipTopRight(
    @Dimension(DP) x: Float,
    @Dimension(DP) y: Float = x,
): LayoutModifier = this then BaseCornerElement(topRightRadius = cornerRadius(x, y))

/**
 * Clips the bottom left corner of the element with [x] as the radius on the horizontal axis and [y]
 * as the radius on the vertical axis.
 */
@RequiresSchemaVersion(major = 1, minor = 400)
public fun LayoutModifier.clipBottomLeft(
    @Dimension(DP) x: Float,
    @Dimension(DP) y: Float = x,
): LayoutModifier = this then BaseCornerElement(bottomLeftRadius = cornerRadius(x, y))

/**
 * Clips the bottom right corner of the element with [x] as the radius on the horizontal axis and
 * [y] as the radius on the vertical axis.
 */
@RequiresSchemaVersion(major = 1, minor = 400)
public fun LayoutModifier.clipBottomRight(
    @Dimension(DP) x: Float,
    @Dimension(DP) y: Float = x,
): LayoutModifier = this then BaseCornerElement(bottomRightRadius = cornerRadius(x, y))

internal class BaseBackgroundElement(val color: LayoutColor? = null, val brush: Brush? = null) :
    BaseProtoLayoutModifiersElement<Background.Builder> {
    @SuppressLint("ProtoLayoutMinSchema") // Relevant callers have correct Requires annotation.
    override fun mergeTo(initialBuilder: Background.Builder?): Background.Builder =
        (initialBuilder ?: Background.Builder()).apply {
            color?.let { setColor(it.prop) }
            brush?.let { setBrush(it) }
        }
}

internal class BaseCornerElement(
    val cornerRadiusDp: Float? = null,
    @RequiresSchemaVersion(major = 1, minor = 400) val topLeftRadius: CornerRadius? = null,
    @RequiresSchemaVersion(major = 1, minor = 400) val topRightRadius: CornerRadius? = null,
    @RequiresSchemaVersion(major = 1, minor = 400) val bottomLeftRadius: CornerRadius? = null,
    @RequiresSchemaVersion(major = 1, minor = 400) val bottomRightRadius: CornerRadius? = null,
) : BaseProtoLayoutModifiersElement<Corner.Builder> {
    @SuppressLint("ProtoLayoutMinSchema")
    override fun mergeTo(initialBuilder: Corner.Builder?): Corner.Builder =
        (initialBuilder ?: Corner.Builder()).apply {
            cornerRadiusDp?.let { setRadius(cornerRadiusDp.dp) }
            topLeftRadius?.let { setTopLeftRadius(cornerRadius(it.x.value, it.y.value)) }
            topRightRadius?.let { setTopRightRadius(cornerRadius(it.x.value, it.y.value)) }
            bottomLeftRadius?.let { setBottomLeftRadius(cornerRadius(it.x.value, it.y.value)) }
            bottomRightRadius?.let { setBottomRightRadius(cornerRadius(it.x.value, it.y.value)) }
        }
}
