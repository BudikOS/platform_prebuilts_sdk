/*
 * Copyright 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

@file:Suppress("FacadeClassJvmName") // Cannot be updated, the Kt name has been released

package androidx.navigation.ui

import androidx.customview.widget.Openable
import androidx.navigation.NavController

/**
 * Handles the Up button by delegating its behavior to the given [NavController].
 *
 * This is equivalent to calling [NavController.navigateUp] if the [Openable] layout is null.
 *
 * @return True if the [NavController] was able to navigate up.
 */
public fun NavController.navigateUp(drawerLayout: Openable?): Boolean =
    NavigationUI.navigateUp(this, AppBarConfiguration(graph, drawerLayout))

/**
 * Handles the Up button by delegating its behavior to the given [NavController].
 *
 * @return True if the [NavController] was able to navigate up.
 */
public fun NavController.navigateUp(appBarConfiguration: AppBarConfiguration): Boolean =
    NavigationUI.navigateUp(this, appBarConfiguration)
