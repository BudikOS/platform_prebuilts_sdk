/*
 * Copyright 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// @exportToFramework:copyToPath(../../../cts/tests/appsearch/testutils/src/android/app/appsearch/testutil/external/LocalStorageIcingOptionsConfig.java)
package androidx.appsearch.localstorage;

import androidx.annotation.RestrictTo;
import androidx.appsearch.flags.Flags;

import org.jspecify.annotations.NonNull;

/**
 * Icing options for AppSearch local-storage. Note, these values are not necessarily the defaults
 * set in {@link com.google.android.icing.proto.IcingSearchEngineOptions} proto.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class LocalStorageIcingOptionsConfig implements IcingOptionsConfig {
    @Override
    public int getMaxTokenLength() {
        return DEFAULT_MAX_TOKEN_LENGTH;
    }

    @Override
    public int getIndexMergeSize() {
        return DEFAULT_INDEX_MERGE_SIZE;
    }

    @Override
    public boolean getDocumentStoreNamespaceIdFingerprint() {
        return true;
    }

    @Override
    public float getOptimizeRebuildIndexThreshold() {
        return 0.9f;
    }

    @Override
    public int getCompressionLevel() {
        return DEFAULT_COMPRESSION_LEVEL;
    }

    @Override
    public int getCompressionMemLevel() {
        return DEFAULT_COMPRESSION_MEM_LEVEL;
    }

    @Override
    public boolean getAllowCircularSchemaDefinitions() {
        return true;
    }

    @Override
    public boolean getUseReadOnlySearch() {
        return true;
    }

    @Override
    public boolean getUsePreMappingWithFileBackedVector() {
        return false;
    }

    @Override
    public boolean getUsePersistentHashMap() {
        return true;
    }

    @Override
    public int getMaxPageBytesLimit() {
        return DEFAULT_MAX_PAGE_BYTES_LIMIT;
    }

    @Override
    public int getMaxPageBytesLimitForVm() {
        return DEFAULT_MAX_PAGE_BYTES_LIMIT;
    }
    @Override
    public int getIntegerIndexBucketSplitThreshold() {
        return DEFAULT_INTEGER_INDEX_BUCKET_SPLIT_THRESHOLD;
    }

    @Override
    public boolean getLiteIndexSortAtIndexing() {
        return DEFAULT_LITE_INDEX_SORT_AT_INDEXING;
    }

    @Override
    public int getLiteIndexSortSize() {
        return DEFAULT_LITE_INDEX_SORT_SIZE;
    }

    @Override
    public boolean getUseNewQualifiedIdJoinIndex() {
        return DEFAULT_USE_NEW_QUALIFIED_ID_JOIN_INDEX;
    }

    @Override
    public boolean getBuildPropertyExistenceMetadataHits() {
        return true;
    }

    @Override
    public long getOrphanBlobTimeToLiveMs() {
        return DEFAULT_ORPHAN_BLOB_TIME_TO_LIVE_MS;
    }

    @Override
    public @NonNull String getIcuDataFileAbsolutePath() {
        return DEFAULT_ICU_DATA_FILE_ABSOLUTE_PATH;
    }

    @Override
    public int getCompressionThresholdBytes() {
        return DEFAULT_COMPRESSION_THRESHOLD_BYTES;
    }

    @Override
    public int getEmbeddingIndexNumShards() {
        return DEFAULT_EMBEDDING_INDEX_NUM_SHARDS;
    }

    @Override
    public boolean enableRepeatedFieldJoins() {
        return Flags.enableRepeatedFieldJoins();
    }

    @Override
    public boolean enableIcingBackgroundTaskScheduler() {
        return true;
    }

    @Override
    public long getExpiredDocumentPurgingThresholdMillis() {
        return DEFAULT_EXPIRED_DOCUMENT_PURGING_THRESHOLD_MILLIS;
    }
}
