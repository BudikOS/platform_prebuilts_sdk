/*
 * Copyright 2021 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.appsearch.platformstorage.converter;

import android.annotation.SuppressLint;
import android.os.Build;

import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.appsearch.app.AppSearchBatchResult;
import androidx.appsearch.app.AppSearchResult;
import androidx.appsearch.exceptions.AppSearchException;
import androidx.concurrent.futures.ResolvableFuture;
import androidx.core.util.Preconditions;

import org.jspecify.annotations.NonNull;

import java.util.Map;
import java.util.function.Function;

/**
 * Translates {@link androidx.appsearch.app.AppSearchResult} and
 * {@link androidx.appsearch.app.AppSearchBatchResult} to platform versions.
 * @exportToFramework:hide
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
@RequiresApi(Build.VERSION_CODES.S)
public final class AppSearchResultToPlatformConverter {
    private AppSearchResultToPlatformConverter() {}

    /**
     * Converts an {@link android.app.appsearch.AppSearchResult} into a jetpack
     * {@link androidx.appsearch.app.AppSearchResult}.
     */
    @SuppressLint("WrongConstant")
    public static <PlatformType, JetpackType> @NonNull AppSearchResult<JetpackType>
            platformAppSearchResultToJetpack(
            android.app.appsearch.@NonNull AppSearchResult<PlatformType> platformResult,
            @NonNull Function<PlatformType, JetpackType> valueMapper) {
        Preconditions.checkNotNull(platformResult);
        if (platformResult.isSuccess()) {
            try {
                JetpackType jetpackType = valueMapper.apply(platformResult.getResultValue());
                return AppSearchResult.newSuccessfulResult(jetpackType);
            } catch (Throwable t) {
                return AppSearchResult.throwableToFailedResult(t);
            }
        }
        return AppSearchResult.newFailedResult(
                // Without the SuppressLint annotation on the method, this line causes a
                // lint error because getResultCode isn't defined as returning a value from
                // AppSearchResult.ResultCode
                platformResult.getResultCode(), platformResult.getErrorMessage());
    }

    /**
     * Uses the given {@link android.app.appsearch.AppSearchResult} to populate the given
     * {@link ResolvableFuture}, transforming it using {@code valueMapper}.
     */
    @SuppressLint("WrongConstant")
    public static <PlatformType, JetpackType> void platformAppSearchResultToFuture(
            android.app.appsearch.@NonNull AppSearchResult<PlatformType> platformResult,
            @NonNull ResolvableFuture<JetpackType> future,
            @NonNull Function<PlatformType, JetpackType> valueMapper) {
        Preconditions.checkNotNull(platformResult);
        Preconditions.checkNotNull(future);
        if (platformResult.isSuccess()) {
            try {
                JetpackType jetpackType = valueMapper.apply(platformResult.getResultValue());
                future.set(jetpackType);
            } catch (Throwable t) {
                future.setException(t);
            }
        } else {
            future.setException(
                    new AppSearchException(
                            platformResult.getResultCode(), platformResult.getErrorMessage()));
        }
    }

    /**
     * Uses the given {@link android.app.appsearch.AppSearchResult} to populate the given
     * {@link ResolvableFuture}.
     */
    public static <T> void platformAppSearchResultToFuture(
            android.app.appsearch.@NonNull AppSearchResult<T> platformResult,
            @NonNull ResolvableFuture<T> future) {
        platformAppSearchResultToFuture(platformResult, future, Function.identity());
    }

    /**
     * Converts the given platform {@link android.app.appsearch.AppSearchBatchResult} to a Jetpack
     * {@link AppSearchBatchResult}.
     *
     * <p>Each value is translated using the provided {@code valueMapper} function.
     */
    public static <K, PlatformValue, JetpackValue> @NonNull AppSearchBatchResult<K, JetpackValue>
            platformAppSearchBatchResultToJetpack(
            android.app.appsearch.@NonNull AppSearchBatchResult<K, PlatformValue> platformResult,
            @NonNull Function<PlatformValue, JetpackValue> valueMapper) {
        return platformAppSearchBatchResultToJetpack(platformResult, Function.identity(),
                valueMapper);
    }

    /**
     * Converts the given platform {@link android.app.appsearch.AppSearchBatchResult} to a Jetpack
     * {@link AppSearchBatchResult}.
     *
     * <p>Each key is translated using the provided {@code keyMapper} function. Each value is
     * translated using the provided {@code valueMapper} function.
     */
    @SuppressLint("WrongConstant")
    public static <PlatformKey, JetpackKey, PlatformValue, JetpackValue> @NonNull
            AppSearchBatchResult<JetpackKey, JetpackValue> platformAppSearchBatchResultToJetpack(
                    android.app.appsearch.@NonNull AppSearchBatchResult<PlatformKey, PlatformValue>
                            platformResult,
            @NonNull Function<PlatformKey, JetpackKey> keyMapper,
            @NonNull Function<PlatformValue, JetpackValue> valueMapper) {
        Preconditions.checkNotNull(platformResult);
        Preconditions.checkNotNull(valueMapper);
        AppSearchBatchResult.Builder<JetpackKey, JetpackValue> jetpackResultBuilder =
                new AppSearchBatchResult.Builder<>();
        platformAppSearchBatchResultToJetpackResultBuilder(platformResult, jetpackResultBuilder,
                keyMapper, valueMapper);
        return jetpackResultBuilder.build();
    }

    /**
     * Converts the given platform {@link android.app.appsearch.AppSearchBatchResult} to a Jetpack
     * {@link AppSearchBatchResult.Builder}.
     *
     * <p>Each key is translated using the provided {@code keyMapper} function. Each value is
     * translated using the provided {@code valueMapper} function.
     */
    @SuppressLint("WrongConstant")
    public static <PlatformKey, JetpackKey, PlatformValue, JetpackValue>
                void platformAppSearchBatchResultToJetpackResultBuilder(
            android.app.appsearch.@NonNull AppSearchBatchResult<PlatformKey, PlatformValue>
                    platformResult,
            AppSearchBatchResult.@NonNull Builder<JetpackKey, JetpackValue> jetpackResultBuilder,
            @NonNull Function<PlatformKey, JetpackKey> keyMapper,
            @NonNull Function<PlatformValue, JetpackValue> valueMapper) {
        Preconditions.checkNotNull(platformResult);
        Preconditions.checkNotNull(valueMapper);
        for (Map.Entry<PlatformKey, PlatformValue> success :
                platformResult.getSuccesses().entrySet()) {
            JetpackKey jetpackKey = keyMapper.apply(success.getKey());
            try {
                JetpackValue jetpackValue = valueMapper.apply(success.getValue());
                jetpackResultBuilder.setSuccess(jetpackKey, jetpackValue);
            } catch (Throwable t) {
                jetpackResultBuilder.setResult(
                        jetpackKey, AppSearchResult.throwableToFailedResult(t));
            }
        }
        for (Map.Entry<PlatformKey, android.app.appsearch.AppSearchResult<PlatformValue>> failure :
                platformResult.getFailures().entrySet()) {
            JetpackKey jetpackKey = keyMapper.apply(failure.getKey());
            int resultCode = failure.getValue().getResultCode();
            String errorMessage = failure.getValue().getErrorMessage();
            // In some situations the error message maybe null if the result code is
            // RESULT_NOT_FOUND.
            // In these cases we should populate the error message.
            if (resultCode == AppSearchResult.RESULT_NOT_FOUND && errorMessage == null) {
                errorMessage = "Document id '" + jetpackKey + "' doesn't exist";
            }
            jetpackResultBuilder.setFailure(
                    jetpackKey,
                    // Without the SuppressLint annotation on the method, this line causes a
                    // lint error because getResultCode isn't defined as returning a value from
                    // AppSearchResult.ResultCode
                    resultCode, errorMessage);
        }
    }
}
