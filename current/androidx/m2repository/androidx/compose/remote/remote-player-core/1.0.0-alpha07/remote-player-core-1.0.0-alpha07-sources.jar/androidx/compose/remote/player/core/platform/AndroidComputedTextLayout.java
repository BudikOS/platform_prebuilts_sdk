/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.compose.remote.player.core.platform;

import static androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP;

import android.text.StaticLayout;

import androidx.annotation.RestrictTo;
import androidx.compose.remote.core.RcPlatformServices;

import org.jspecify.annotations.NonNull;

@RestrictTo(LIBRARY_GROUP)
public class AndroidComputedTextLayout implements RcPlatformServices.ComputedTextLayout {
    StaticLayout mStaticLayout;
    float mWidth;
    float mHeight;
    int mLineCount;
    boolean mIsHyphenatedText;

    public AndroidComputedTextLayout(@NonNull StaticLayout staticLayout, float width,
            float height, int lineCount, boolean isHyphenatedText) {
        mStaticLayout = staticLayout;
        mWidth = width;
        mHeight = height;
        mLineCount = lineCount;
        mIsHyphenatedText = isHyphenatedText;
    }

    /**
     * Set a StaticLayout on this container
     */
    public void set(@NonNull StaticLayout layout) {
        mStaticLayout = layout;
    }

    /**
     * Retrieve the stored StaticLayout
     */
    @NonNull
    public StaticLayout get() {
        return mStaticLayout;
    }

    @Override
    public float getWidth() {
        return mWidth;
    }

    @Override
    public float getHeight() {
        return mHeight;
    }

    @Override
    public int getVisibleLineCount() {
        return mLineCount;
    }

    @Override
    public boolean isHyphenatedText() {
        return mIsHyphenatedText;
    }
}
