/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.remote.creation.compose.modifier

import androidx.annotation.RestrictTo
import androidx.compose.remote.creation.compose.action.Action
import androidx.compose.remote.creation.compose.state.RemoteStateScope
import androidx.compose.remote.creation.modifiers.RecordingModifier
import androidx.compose.remote.creation.modifiers.TouchActionModifier

internal class TouchDownActionModifier(public val actions: List<Action>) : RemoteModifier.Element {
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    override fun RemoteStateScope.toRecordingModifierElement(): RecordingModifier.Element {
        return androidx.compose.remote.creation.modifiers.TouchActionModifier(
            TouchActionModifier.DOWN,
            @Suppress("ListIterator") actions.map { action -> with(action) { toRemoteAction() } },
        )
    }
}

public fun RemoteModifier.onTouchDown(vararg actions: Action): RemoteModifier =
    then(TouchDownActionModifier(actions.toList()))

public fun RemoteModifier.onTouchDown(actions: List<Action>): RemoteModifier =
    then(TouchDownActionModifier(actions))
