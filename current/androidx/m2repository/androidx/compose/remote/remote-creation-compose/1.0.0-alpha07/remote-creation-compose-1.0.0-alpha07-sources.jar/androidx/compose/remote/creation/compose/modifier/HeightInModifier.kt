/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.remote.creation.compose.modifier

import androidx.annotation.RestrictTo
import androidx.compose.remote.creation.compose.state.RemoteDp
import androidx.compose.remote.creation.compose.state.RemoteStateScope
import androidx.compose.remote.creation.modifiers.RecordingModifier

internal class HeightInModifier(val min: RemoteDp? = null, val max: RemoteDp? = null) :
    RemoteModifier.Element {
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    override fun RemoteStateScope.toRecordingModifierElement(): RecordingModifier.Element {
        var minValue = 0f
        var maxValue = Float.MAX_VALUE
        if (min != null) {
            // specified in Dp values
            minValue = min.value.floatId
        }
        if (max != null) {
            // specified in Dp values
            maxValue = max.value.floatId
        }
        return androidx.compose.remote.creation.modifiers.HeightInModifier(minValue, maxValue)
    }
}

/**
 * Sets the minimum and maximum height of the content.
 *
 * @param min The minimum height.
 * @param max The maximum height.
 */
public fun RemoteModifier.heightIn(min: RemoteDp? = null, max: RemoteDp? = null): RemoteModifier {
    return then(HeightInModifier(min = min, max = max))
}
