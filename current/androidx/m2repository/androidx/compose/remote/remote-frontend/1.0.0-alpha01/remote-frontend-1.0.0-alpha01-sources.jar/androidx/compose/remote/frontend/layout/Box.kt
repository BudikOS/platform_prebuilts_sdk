/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
@file:RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)

package androidx.compose.remote.frontend.layout

import androidx.annotation.RestrictTo
import androidx.compose.remote.frontend.modifier.RemoteModifier
import androidx.compose.runtime.Composable

/** Capture a Box layout as a RemoteBox */
@RemoteComposable
@Composable
public fun Box(
    modifier: RemoteModifier = RemoteModifier,
    horizontalAlignment: Alignment.Horizontal = Alignment.Start,
    verticalArrangement: Arrangement.Vertical = Arrangement.Top,
    content: @Composable () -> Unit,
) {
    RemoteBox(modifier, horizontalAlignment, verticalArrangement, content)
}

/** Utility function to support Box with no provided content */
@RemoteComposable
@Composable
public fun Box(modifier: RemoteModifier = RemoteModifier) {
    RemoteBox(modifier)
}
