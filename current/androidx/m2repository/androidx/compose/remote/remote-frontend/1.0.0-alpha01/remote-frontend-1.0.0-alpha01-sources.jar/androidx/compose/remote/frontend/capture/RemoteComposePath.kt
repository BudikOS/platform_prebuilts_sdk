/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
@file:RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)

package androidx.compose.remote.frontend.capture

import android.graphics.Path
import androidx.annotation.RestrictTo
import androidx.compose.remote.creation.RemotePath
import androidx.compose.ui.graphics.asComposePath

/**
 * This wraps a RemotePath in class that implements Compose.ui.graphicsPath This would allow passing
 * path through standard compose interfaces. But providing access to the RemotePath object
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class RemoteComposePath(
    foo: androidx.compose.ui.graphics.Path,
    public val remote: RemotePath,
) : androidx.compose.ui.graphics.Path by foo {
    public fun asAndroidPath(): Path {
        return remote.path
    }
}

public fun RemotePath.asComposePath(): RemoteComposePath {
    return RemoteComposePath(this.path.asComposePath(), this)
}
