/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
@file:RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)

package androidx.compose.remote.player.compose

import androidx.annotation.RestrictTo
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.remote.core.CoreDocument
import androidx.compose.remote.core.operations.Theme
import androidx.compose.remote.player.core.RemoteDocument
import androidx.compose.remote.player.core.action.NamedActionHandler
import androidx.compose.remote.player.core.action.StateUpdaterActionCallback
import androidx.compose.remote.player.core.platform.BitmapLoader
import androidx.compose.remote.player.core.state.StateUpdater
import androidx.compose.remote.player.view.RemoteComposePlayer
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

/** A player of a [CoreDocument] */
@OptIn(ExperimentalRemotePlayerApi::class)
@Composable
public fun RemoteDocumentPlayer(
    document: CoreDocument,
    documentWidth: Int,
    documentHeight: Int,
    modifier: Modifier = Modifier,
    debugMode: Int = 0,
    init: (RemoteComposePlayer) -> Unit = {},
    update: (RemoteComposePlayer) -> Unit = {},
    onAction: (actionId: Int, value: String?) -> Unit = { _, _ -> },
    onNamedAction: (name: String, value: Any?, stateUpdater: StateUpdater) -> Unit = { _, _, _ -> },
    bitmapLoader: BitmapLoader? = null,
) {
    var inDarkTheme by remember { mutableStateOf(false) }
    var playbackTheme by remember { mutableIntStateOf(Theme.UNSPECIFIED) }

    val remoteDoc = remember(document) { RemoteDocument(document) }

    inDarkTheme =
        when (AppCompatDelegate.getDefaultNightMode()) {
            AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM -> isSystemInDarkTheme()
            AppCompatDelegate.MODE_NIGHT_YES -> true
            AppCompatDelegate.MODE_NIGHT_NO -> false
            AppCompatDelegate.MODE_NIGHT_UNSPECIFIED -> isSystemInDarkTheme()
            else -> {
                false
            }
        }

    playbackTheme =
        if (inDarkTheme) {
            Theme.DARK
        } else {
            Theme.LIGHT
        }

    val androidViewModifier =
        modifier.then(
            if (RemoteComposePlayerFlags.shouldPlayerWrapContentSize) {
                // The modifier defaults to wrapContentSize, meaning the view will size itself to
                // the content of the RemoteComposePlayer. However, this can be overridden by the
                // external modifier provided to RemoteDocumentPlayer.
                Modifier.wrapContentSize()
            } else {
                Modifier.size(documentWidth.dp, documentHeight.dp)
            }
        )

    AndroidView(
        modifier = androidViewModifier,
        factory = {
            RemoteComposePlayer(it).apply {
                init(this)
                if (bitmapLoader != null) {
                    setBitmapLoader(bitmapLoader)
                }
            }
        },
        update = { remoteComposePlayer ->
            remoteComposePlayer.setTheme(playbackTheme)
            remoteComposePlayer.setDocument(remoteDoc)
            remoteComposePlayer.setDebug(debugMode)
            remoteComposePlayer.document.document.clearActionCallbacks()
            remoteComposePlayer.document.document.addIdActionListener { id, value ->
                onAction.invoke(id, value)
            }
            remoteComposePlayer.document.document.addActionCallback(
                object :
                    StateUpdaterActionCallback(
                        remoteComposePlayer.stateUpdater,
                        object : NamedActionHandler {
                            override fun execute(
                                name: String,
                                value: Any?,
                                stateUpdater: StateUpdater,
                            ) {
                                onNamedAction.invoke(name, value, stateUpdater)
                            }
                        },
                    ) {}
            )
            // use
            update(remoteComposePlayer)
        },
    )
}
