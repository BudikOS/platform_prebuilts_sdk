/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.core.app;

final class AndroidAppFlags {
    public static final String PACKAGE = "android.app";

    public static final String FLAG_API_METRIC_STYLE = "api_metric_style";
    public static final String FLAG_API_NOTIFICATION_ACTION_CUSTOM =
            "api_notification_action_custom";
    public static final String FLAG_API_NOTIFICATION_SEMANTIC_STYLE =
            "api_notification_semantic_style";

    private AndroidAppFlags() { }
}
