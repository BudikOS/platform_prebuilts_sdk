/*
 * Copyright 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.privacysandbox.ui.core

/** Contains UI Lib experimental feature opt-in annotations. */
@Deprecated("This library is no longer supported.")
public sealed interface ExperimentalFeatures {
    @RequiresOptIn(
        "This API is experimental. It may be changed in the future without notice.",
        RequiresOptIn.Level.WARNING,
    )
    @Retention(AnnotationRetention.BINARY)
    public annotation class DelegatingAdapterApi

    @RequiresOptIn(
        "This API is experimental. It may be changed in the future without notice.",
        RequiresOptIn.Level.WARNING,
    )
    @Retention(AnnotationRetention.BINARY)
    public annotation class SharedUiPresentationApi

    @RequiresOptIn(
        "This API is experimental. It may be changed in the future without notice.",
        RequiresOptIn.Level.WARNING,
    )
    @Retention(AnnotationRetention.BINARY)
    public annotation class ChangingContentUiZOrderApi
}
