/*
 * Copyright 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.car.app.model;

import androidx.annotation.IntDef;
import androidx.annotation.OptIn;
import androidx.annotation.RestrictTo;
import androidx.car.app.annotations.CarProtocol;
import androidx.car.app.annotations.ExperimentalCarApi;
import androidx.car.app.annotations.KeepFields;
import androidx.car.app.annotations.RequiresCarApi;
import androidx.car.app.model.constraints.ActionsConstraints;

import com.google.errorprone.annotations.CanIgnoreReturnValue;

import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/** A template that contains sections of items like rows, grid items, chips, etc. */
@KeepFields
@RequiresCarApi(8)
@CarProtocol
public final class SectionedItemTemplate implements Template {
    /**
     * Denotes possible strategies for preserving a user's scroll position when this template is
     * refreshed.
     */
    @IntDef(value = {SCROLL_STATE_RESET_TO_TOP, SCROLL_STATE_PRESERVE_INDEX})
    @Retention(RetentionPolicy.SOURCE)
    @RestrictTo(RestrictTo.Scope.LIBRARY)
    public @interface ScrollStatePersistenceStrategy {
    }

    /**
     * Indicate that the scroll position should reset back to the top when this template is
     * refreshed.
     *
     * <p>This is the default behavior if not explicitly set.
     */
    @ScrollStatePersistenceStrategy
    public static final int SCROLL_STATE_RESET_TO_TOP = 0;

    /**
     * Indicate that the scroll position should be preserved by scrolling back down to the same
     * index that the user had scrolled to.
     *
     * <p>If the index no longer exists, the scroll position will be set to the bottom of the new
     * list.
     */
    @ScrollStatePersistenceStrategy
    public static final int SCROLL_STATE_PRESERVE_INDEX = 1;

    /**
     * Denotes possible strategies for alphabetical indexing which allows items in this template
     * to be sorted or "jumped" to via UI affordances (for example, a keyboard to jump to a
     * starting letter within a list of contacts).
     */
    @IntDef(value = {ALPHABETICAL_INDEXING_DISABLED, ALPHABETICAL_INDEXING_TITLE_AS_IS,
            ALPHABETICAL_INDEXING_TITLE_IGNORE_ARTICLES_AND_SYMBOLS})
    @Retention(RetentionPolicy.SOURCE)
    @RestrictTo(RestrictTo.Scope.LIBRARY)
    public @interface AlphabeticalIndexingStrategy {
    }

    /**
     * Indicate that alphabetical indexing should not be available for the template which also
     * disables any UI accelerators that the user may be shown to help the user navigate larger
     * lists.
     *
     * <p>This is the default behavior if not explicitly set.
     */
    @AlphabeticalIndexingStrategy
    public static final int ALPHABETICAL_INDEXING_DISABLED = 0;

    /**
     * Indicates that alphabetical indexing should use the item's title as-is with no processing.
     *
     * <p>Note that a UI accelerator may still group the item under the "miscellaneous" category
     * if the title starts with a non-alphabetical character.
     */
    @AlphabeticalIndexingStrategy
    public static final int ALPHABETICAL_INDEXING_TITLE_AS_IS = 1;

    /**
     * Indicates that alphabetical indexing should ignore English articles (like "the", "an", and
     * "a") as well as non-alphanumeric symbols.
     *
     * <p>Note this will not change the display of the item's title, just how it's sorted. For
     * example, "The Example Song" will continue to show up as "The Example Song", but will be
     * sorted into the "E" bucket.
     */
    @AlphabeticalIndexingStrategy
    public static final int ALPHABETICAL_INDEXING_TITLE_IGNORE_ARTICLES_AND_SYMBOLS = 2;

    private final @NonNull List<Section<?>> mSections;

    private final @NonNull List<Action> mActions;

    private final @Nullable Header mHeader;

    private final boolean mIsLoading;

    @Deprecated
    private final boolean mIsAlphabeticalIndexingAllowed;

    private final int mAlphabeticalIndexingStrategy;

    private final int mScrollStatePersistenceStrategy;

    // Empty constructor for serialization
    private SectionedItemTemplate() {
        mSections = Collections.emptyList();
        mActions = Collections.emptyList();
        mHeader = null;
        mIsLoading = false;
        mIsAlphabeticalIndexingAllowed = false;
        mAlphabeticalIndexingStrategy = ALPHABETICAL_INDEXING_DISABLED;
        mScrollStatePersistenceStrategy = SCROLL_STATE_PRESERVE_INDEX;
    }

    /** Creates a {@link SectionedItemTemplate} from the {@link Builder}. */
    private SectionedItemTemplate(Builder builder) {
        mSections = Collections.unmodifiableList(builder.mSections);
        mActions = Collections.unmodifiableList(builder.mActions);
        mHeader = builder.mHeader;
        mIsLoading = builder.mIsLoading;
        mIsAlphabeticalIndexingAllowed = builder.mIsAlphabeticalIndexingAllowed;
        mAlphabeticalIndexingStrategy = builder.mAlphabeticalIndexingStrategy;
        mScrollStatePersistenceStrategy = builder.mScrollStatePersistenceStrategy;
    }

    /** Returns the list of sections within this template. */
    public @NonNull List<Section<?>> getSections() {
        return mSections;
    }

    /** Returns the list of actions that should appear alongside the content of this template. */
    public @NonNull List<Action> getActions() {
        return mActions;
    }

    /** Returns the optional header for this template. */
    public @Nullable Header getHeader() {
        return mHeader;
    }

    /** Returns whether or not this template is in a loading state. */
    public boolean isLoading() {
        return mIsLoading;
    }

    /**
     * Returns whether this list can be indexed alphabetically, by item title.
     *
     * <p>"Indexing" refers to the process of examining list contents (e.g. item titles) to sort,
     * partition, or filter a list. Indexing is generally used for features called "Accelerators",
     * which allow a user to quickly find a particular {@link Item} in a long list.
     *
     * <p>To exclude a single item from indexing, see the relevant item's API.
     *
     * <p>To enable/disable accelerators for the entire list, see
     * {@link SectionedItemTemplate.Builder#setAlphabeticalIndexingAllowed(boolean)}
     *
     * @deprecated use {@link #getAlphabeticalIndexingStrategy()} with
     * {@link SectionedItemTemplate.Builder#setAlphabeticalIndexingStrategy(int)}
     */
    @Deprecated
    public boolean isAlphabeticalIndexingAllowed() {
        return mIsAlphabeticalIndexingAllowed;
    }

    /**
     * Returns the alphabetical indexing strategy.
     *
     * <p>"Indexing" refers to the process of examining list contents (e.g. item titles) to sort,
     * partition, or filter a list. Indexing is generally used for features called "Accelerators",
     * which allow a user to quickly find a particular {@link Item} in a long list.
     *
     * <p>Individual items may be excluded from the list by setting their {@code #isIndexable}
     * field to {@code false}.
     */
    @AlphabeticalIndexingStrategy
    public int getAlphabeticalIndexingStrategy() {
        // Existing field is used if the new field is set to DISABLED
        if (mAlphabeticalIndexingStrategy == ALPHABETICAL_INDEXING_DISABLED
                && mIsAlphabeticalIndexingAllowed) {
            return ALPHABETICAL_INDEXING_TITLE_IGNORE_ARTICLES_AND_SYMBOLS;
        }

        return mAlphabeticalIndexingStrategy;
    }

    /**
     * Returns the strategy to use when this template is used as a refresh.
     *
     * See {@link Builder#setScrollStatePersistenceStrategy(int)}
     */
    @ScrollStatePersistenceStrategy
    public int getScrollStatePersistenceStrategy() {
        return mScrollStatePersistenceStrategy;
    }

    @Override
    public int hashCode() {
        return Objects.hash(mSections,
                mActions,
                mHeader,
                mIsLoading,
                mIsAlphabeticalIndexingAllowed,
                mScrollStatePersistenceStrategy
        );
    }

    @Override
    public boolean equals(@Nullable Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (!(other instanceof SectionedItemTemplate)) {
            return false;
        }
        SectionedItemTemplate template = (SectionedItemTemplate) other;
        return Objects.equals(mSections, template.mSections)
                && Objects.equals(mActions, template.mActions)
                && Objects.equals(mHeader, template.mHeader)
                && mIsLoading == template.mIsLoading
                && mIsAlphabeticalIndexingAllowed == template.mIsAlphabeticalIndexingAllowed
                && mScrollStatePersistenceStrategy == template.mScrollStatePersistenceStrategy;
    }

    @Override
    public @NonNull String toString() {
        return "SectionedItemTemplate";
    }

    /**
     * A builder that constructs {@link SectionedItemTemplate} instances.
     *
     * <p>Upon building, this class validates the following:
     *
     * <ul>
     *     <li>The template is not both loading and populated with sections
     *     <li>Only {@link ChipSection}, {@link RowSection} and/or {@link GridSection} are
     *     added as sections
     *     <li>If a {@link ChipSection} is added, it must be the first section and only one
     *     is allowed
     * </ul>
     */
    public static final class Builder {
        private @NonNull List<Section<?>> mSections = new ArrayList<>();

        private @NonNull List<Action> mActions = new ArrayList<>();

        private @Nullable Header mHeader = null;

        private boolean mIsLoading = false;

        private boolean mIsAlphabeticalIndexingAllowed = false;

        private int mAlphabeticalIndexingStrategy = ALPHABETICAL_INDEXING_DISABLED;

        private int mScrollStatePersistenceStrategy = SCROLL_STATE_PRESERVE_INDEX;

        /** Create a new {@link SectionedItemTemplate} builder. */
        public Builder() {
        }

        /**
         * Create a new {@link SectionedItemTemplate} builder, copying the values from an existing
         * instance.
         */
        public Builder(@NonNull SectionedItemTemplate template) {
            mSections = template.mSections;
            mActions = template.mActions;
            mHeader = template.mHeader;
            mIsLoading = template.mIsLoading;
            mIsAlphabeticalIndexingAllowed = template.mIsAlphabeticalIndexingAllowed;
            mAlphabeticalIndexingStrategy = template.mAlphabeticalIndexingStrategy;
            mScrollStatePersistenceStrategy = template.mScrollStatePersistenceStrategy;
        }

        /**
         * Sets the sections in this template, overwriting any other previously set sections. Only
         * sections listed in {@link Builder} can be added.
         *
         * @see Builder for a list of allowed section types
         */
        @CanIgnoreReturnValue
        public @NonNull Builder setSections(@NonNull List<Section<?>> sections) {
            mSections = sections;
            return this;
        }

        /**
         * Adds a single {@link Section} to this template, appending to the existing list of
         * sections. Only sections listed in {@link Builder} can be added.
         *
         * @see Builder for a list of allowed section types
         */
        @CanIgnoreReturnValue
        public @NonNull Builder addSection(@NonNull Section<?> section) {
            mSections.add(section);
            return this;
        }

        /** Removes all sections from this template. */
        @CanIgnoreReturnValue
        public @NonNull Builder clearSections() {
            mSections.clear();
            return this;
        }

        /**
         * Sets the actions that show up alongside the sections of this template (as opposed to the
         * actions in the header), overwriting any other previously set actions from {@link
         * #addAction(Action)} or {@link #setActions(List)}. All actions must conform to the
         * {@link ActionsConstraints#ACTIONS_CONSTRAINTS_FAB} constraints.
         */
        @CanIgnoreReturnValue
        public @NonNull Builder setActions(@NonNull List<Action> actions) {
            ActionsConstraints.ACTIONS_CONSTRAINTS_FAB.validateOrThrow(actions);
            mActions = actions;
            return this;
        }

        /**
         * Adds a single {@link Action} to this template, appending to the existing list of
         * actions. All actions must conform to the
         * {@link ActionsConstraints#ACTIONS_CONSTRAINTS_FAB} constraints.
         */
        @CanIgnoreReturnValue
        public @NonNull Builder addAction(@NonNull Action action) {
            List<Action> actionsCopy = new ArrayList<>(mActions);
            actionsCopy.add(action);
            ActionsConstraints.ACTIONS_CONSTRAINTS_FAB.validateOrThrow(actionsCopy);

            mActions.add(action);
            return this;
        }

        /** Removes all actions in this template. */
        @CanIgnoreReturnValue
        public @NonNull Builder clearActions() {
            mActions.clear();
            return this;
        }

        /** Sets or clears the optional header for this template. */
        @CanIgnoreReturnValue
        public @NonNull Builder setHeader(@Nullable Header header) {
            mHeader = header;
            return this;
        }

        /**
         * Sets whether or not this template is in a loading state. If passed {@code true}, sections
         * cannot be added to the template. By default, this is {@code false}.
         */
        @CanIgnoreReturnValue
        public @NonNull Builder setLoading(boolean isLoading) {
            mIsLoading = isLoading;
            return this;
        }

        /**
         * Sets whether this list can be indexed alphabetically, by item title. By default, this
         * is {@code false}.
         *
         * <p>"Indexing" refers to the process of examining list contents (e.g. item titles) to
         * sort, partition, or filter a list. Indexing is generally used for features called
         * "Accelerators", which allow a user to quickly find a particular {@link Item} in a long
         * list.
         *
         * <p>For example, a media app may, by default, show a user's playlists sorted by date
         * created. If the app provides these playlists via the {@code SectionedItemTemplate} and
         * enables {@link #isAlphabeticalIndexingAllowed}, the user will be able to jump to their
         * playlists that start with the letter "H". When this happens, the list is reconstructed
         * and sorted alphabetically, then shown to the user, jumping down to the letter "H".
         *
         * <p>Individual items may be excluded from the list by setting their {@code #isIndexable}
         * field to {@code false}.
         *
         * @deprecated use {@link #setAlphabeticalIndexingStrategy(int)} instead. This method will
         * default to setting {@link #ALPHABETICAL_INDEXING_TITLE_IGNORE_ARTICLES_AND_SYMBOLS}.
         */
        @Deprecated
        @CanIgnoreReturnValue
        public @NonNull Builder setAlphabeticalIndexingAllowed(
                boolean alphabeticalIndexingAllowed) {
            mIsAlphabeticalIndexingAllowed = alphabeticalIndexingAllowed;
            return this;
        }

        /**
         * Sets how this list can be indexed alphabetically. By default, this is
         * {@link #ALPHABETICAL_INDEXING_DISABLED}.
         *
         * <p>"Indexing" refers to the process of examining list contents (e.g. item titles) to
         * sort, partition, or filter a list. Indexing is generally used for features called
         * "Accelerators", which allow a user to quickly find a particular {@link Item} in a long
         * list.
         *
         * <p>For example, a media app may, by default, provide a user's playlists sorted by date
         * created in {@link #addSection(Section)}. If {@link #setAlphabeticalIndexingStrategy(int)}
         * is set to a non-disabled value, the user will be able to jump to their playlists that
         * start with the letter "H". When this happens, the list is reconstructed and sorted
         * alphabetically, then shown to the user, jumping down to the letter "H".
         *
         * <p>Individual items may be excluded from the reconstructed list by setting their
         * {@code #isIndexable} field to {@code false}.
         */
        @CanIgnoreReturnValue
        public @NonNull Builder setAlphabeticalIndexingStrategy(
                @AlphabeticalIndexingStrategy int alphabeticalIndexingStrategy) {
            mAlphabeticalIndexingStrategy = alphabeticalIndexingStrategy;
            // Set the legacy field for older host versions. Indexing is allowed when the strategy
            // is NOT disabled.
            mIsAlphabeticalIndexingAllowed =
                    alphabeticalIndexingStrategy != ALPHABETICAL_INDEXING_DISABLED;
            return this;
        }

        /**
         * Set how to handle a user's scroll position when this template is used as a refresh of
         * another {@link SectionedItemTemplate}.
         *
         * <p>For example, if a user is currently scrolled down to item 10 in an existing
         * {@link SectionedItemTemplate}, setting this field to
         * {@link SectionedItemTemplate#SCROLL_STATE_PRESERVE_INDEX} would cause the user to
         * be shown item 10 from this template. Alternatively,
         * {@link SectionedItemTemplate#SCROLL_STATE_RESET_TO_TOP} would cause the user to be reset
         * to the top of this template.
         *
         * <p>By default, this is set to {@link SectionedItemTemplate#SCROLL_STATE_RESET_TO_TOP}.
         */
        @CanIgnoreReturnValue
        public @NonNull Builder setScrollStatePersistenceStrategy(
                @ScrollStatePersistenceStrategy int scrollStatePersistenceStrategy) {
            mScrollStatePersistenceStrategy = scrollStatePersistenceStrategy;
            return this;
        }

        /**
         * Constructs a new {@link SectionedItemTemplate} from the current state of this builder,
         * throwing exceptions for any invalid state.
         *
         * @see Builder for the list of validation logic
         */
        @OptIn(markerClass = ExperimentalCarApi.class)
        public @NonNull SectionedItemTemplate build() {
            if (mIsLoading) {
                if (!mSections.isEmpty()) {
                    throw new IllegalArgumentException(
                            "A template cannot both be in a loading state and have sections added");
                }
            }

            boolean hasChipSection = false;
            for (int i = 0; i < mSections.size(); i++) {
                Section<?> section = mSections.get(i);
                if (section instanceof ChipSection) {
                    if (hasChipSection) {
                        throw new IllegalArgumentException(
                                "Only one ChipSection is allowed in SectionedItemTemplate.");
                    }
                    if (i != 0) {
                        throw new IllegalArgumentException(
                                "ChipSection must be the first section in "
                                        + "SectionedItemTemplate.");
                    }
                    hasChipSection = true;
                } else if (!(section instanceof RowSection) && !(section instanceof GridSection)) {
                    throw new IllegalArgumentException(
                            "Only ChipSections, RowSections and GridSections are allowed in "
                                    + "SectionedItemTemplate.");
                }
            }

            return new SectionedItemTemplate(this);
        }
    }
}
