/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.appfunctions.internal

import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.annotation.RestrictTo
import androidx.appfunctions.internal.Constants.APP_FUNCTIONS_TAG

/** Provides manual dependency injection for AppFunction runtime infrastructure. */
@RequiresApi(Build.VERSION_CODES.S)
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public object Dependencies {
    public val translatorSelector: TranslatorSelector by lazy {
        try {
            TranslatorSelector::class.java.findImpl(prefix = "", suffix = "Impl")
        } catch (ex: Exception) {
            Log.d(APP_FUNCTIONS_TAG, "Cannot find TranslatorSelectorImpl")
            NullTranslatorSelector()
        }
    }

    internal val schemaAppFunctionInventory: SchemaAppFunctionInventory? by lazy {
        try {
            SchemaAppFunctionInventory::class.java.findImpl(prefix = "$", suffix = "_Impl")
        } catch (e: Exception) {
            Log.d(APP_FUNCTIONS_TAG, "Cannot find SchemaAppFunctionInventory implementation")
            null
        }
    }

    public val aggregatedAppFunctionInventory: AggregatedAppFunctionInventory? by lazy {
        try {
            AggregatedAppFunctionInventory::class.java.findImpl(prefix = "$", suffix = "_Impl")
        } catch (e: Exception) {
            Log.d(APP_FUNCTIONS_TAG, "Cannot find AggregatedAppFunctionInventory implementation", e)
            null
        }
    }

    /**
     * Returns the AggregatedAppFunctionInventory if available else the SchemaAppFunctionInventory.
     *
     * If both are not available, returns null.
     */
    internal val appFunctionInventory: AppFunctionInventory? by lazy {
        if (aggregatedAppFunctionInventory != null) return@lazy aggregatedAppFunctionInventory

        return@lazy schemaAppFunctionInventory
    }
}
