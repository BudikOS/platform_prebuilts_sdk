/*
 * Copyright 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.camera.camera2.compat.workaround

import android.hardware.camera2.CameraDevice
import androidx.camera.camera2.adapter.CaptureConfigAdapter.Companion.getStillCaptureTemplate
import androidx.camera.camera2.compat.quirk.DeviceQuirks
import androidx.camera.camera2.compat.quirk.TorchIsClosedAfterImageCapturingQuirk
import androidx.camera.camera2.config.UseCaseCameraScope
import androidx.camera.camera2.impl.Camera2Logger
import androidx.camera.camera2.impl.CameraProperties
import androidx.camera.camera2.impl.CapturePipeline
import androidx.camera.camera2.impl.CapturePipelineImpl
import androidx.camera.camera2.impl.TorchControl
import androidx.camera.camera2.impl.TorchControl.TorchMode
import androidx.camera.camera2.impl.UseCaseThreads
import androidx.camera.camera2.pipe.CameraMetadata.Companion.isHardwareLevelLegacy
import androidx.camera.camera2.pipe.RequestTemplate
import androidx.camera.core.ImageCapture
import androidx.camera.core.TorchState
import androidx.camera.core.imagecapture.CameraCapturePipeline
import androidx.camera.core.impl.CaptureConfig
import androidx.camera.core.impl.Config
import javax.inject.Inject
import javax.inject.Provider
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch

/**
 * This is a workaround for b/228272227 where the Torch is unexpectedly closed after a single
 * capturing.
 *
 * If the Torch is enabled before performing a single capture, this workaround may turn the Torch
 * OFF then ON after the capturing.
 */
@UseCaseCameraScope
public class CapturePipelineTorchCorrection
@Inject
constructor(
    cameraProperties: CameraProperties,
    private val capturePipelineImplProvider: Provider<CapturePipelineImpl>,
    private val threads: UseCaseThreads,
    private val torchControl: TorchControl,
) : CapturePipeline {
    private val isLegacyDevice by lazy { cameraProperties.metadata.isHardwareLevelLegacy }
    private val capturePipelineImpl by lazy { capturePipelineImplProvider.get() }

    override suspend fun submitStillCaptures(
        configs: List<CaptureConfig>,
        requestTemplate: RequestTemplate,
        sessionConfigOptions: Config,
        @ImageCapture.CaptureMode captureMode: Int,
        @ImageCapture.FlashType flashType: Int,
        @ImageCapture.FlashMode flashMode: Int,
    ): List<Deferred<Void?>> {
        val needCorrectTorchState = isCorrectionRequired(configs, requestTemplate)

        // Forward the capture request to capturePipelineImpl
        val deferredResults =
            capturePipelineImpl.submitStillCaptures(
                configs,
                requestTemplate,
                sessionConfigOptions,
                captureMode,
                flashType,
                flashMode,
            )

        if (needCorrectTorchState) {
            threads.sequentialScope.launch {
                deferredResults.joinAll()
                Camera2Logger.debug { "Re-enable Torch to correct the Torch state" }
                torchControl.setTorchAsync(TorchMode.OFF).join()
                torchControl.setTorchAsync(TorchMode.USED_AS_FLASH).join()
                Camera2Logger.debug { "Re-enable Torch to correct the Torch state, done" }
            }
        }

        return deferredResults
    }

    override suspend fun getCameraCapturePipeline(
        captureMode: Int,
        flashMode: Int,
        flashType: Int,
    ): CameraCapturePipeline =
        capturePipelineImpl.getCameraCapturePipeline(captureMode, flashMode, flashType)

    override var template: Int = CameraDevice.TEMPLATE_PREVIEW
        set(value) {
            capturePipelineImpl.template = value
            field = value
        }

    /**
     * Return true means the Torch will be unexpectedly closed, and it requires turning on the Torch
     * again after the capturing.
     */
    private fun isCorrectionRequired(
        captureConfigs: List<CaptureConfig>,
        requestTemplate: RequestTemplate,
    ): Boolean {
        return captureConfigs.any {
            it.getStillCaptureTemplate(requestTemplate, isLegacyDevice).value ==
                CameraDevice.TEMPLATE_STILL_CAPTURE
        } && isTorchOn()
    }

    private fun isTorchOn() = torchControl.torchStateLiveData.value == TorchState.ON

    public companion object {
        public val isEnabled: Boolean =
            DeviceQuirks[TorchIsClosedAfterImageCapturingQuirk::class.java] != null
    }
}
